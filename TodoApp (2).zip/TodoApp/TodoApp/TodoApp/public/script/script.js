//let taskList = []; 
let categories = [];
let editingIndex = null;
let currentCategory = "ALL";
let editingTaskId = null;

function showInput(task = null) {
  const popup = document.getElementById('popups');
  popup.style.display = 'block';

  if (task) {
    editingTaskId = task._id;
    document.getElementById('taskInput').value = task.title;
    document.getElementById('taskDate').value = task.date ? new Date(task.date).toISOString().substr(0, 10) : '';
    document.getElementById('taskDesc').value = task.description || '';
    document.getElementById('taskCategory').value = task.category || '';
    document.getElementById('taskForm').action = `/todoapp/edit/${task._id}`;
    document.getElementById('formSubmitBtn').textContent = 'Simpan';
  } else {
    editingTaskId = null;
    document.getElementById('taskForm').action = '/todoapp/add';
    document.getElementById('formSubmitBtn').textContent = 'Tambah';
  }
}

function editTaskClient(taskId) {
  // Ambil data task dari server menggunakan ID
  fetch(`/task/${taskId}`)
    .then(response => response.json())
    .then(task => {
      // Isi form dengan data task yang ada
      document.getElementById('taskInput').value = task.title;
      document.getElementById('taskDate').value = task.date || '';
      document.getElementById('taskDesc').value = task.description || '';
      document.getElementById('taskCategory').value = task.category || '';
      // Menampilkan popup
      document.getElementById('popups').style.display = 'block';
    })
    .catch(err => {
      console.error('Error fetching task data:', err);
    });
}


function showEditPopup(taskId) {
  console.log("Edit task with ID:", taskId);  // Debugging
  fetch(`/task/${taskId}`)
    .then(response => response.json())
    .then(task => {
      document.getElementById('task-id').value = task._id;
      document.getElementById('title').value = task.title;
      document.getElementById('description').value = task.description;
      document.getElementById('task-form-popup').style.display = 'block';  // Menampilkan popup
    })
    .catch(err => {
      console.error('Error fetching task data:', err);
    });
}


function showInput() {
  document.getElementById('popup').style.display = 'block';
}

function hideInput() {
    document.getElementById('popup').style.display = 'none';
    document.getElementById('taskInput').value = '';
    document.getElementById('taskDate').value = '';
    document.getElementById('taskDesc').value = '';
    editingIndex = null;
  }

  function toggleComplete(taskId, buttonElement) {
    fetch(`/todoapp/complete/${taskId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        const taskCard = buttonElement.closest('.task-card');
        const title = taskCard.querySelector('h3');
  
        // Toggle class
        if (taskCard.classList.contains('done')) {
          taskCard.classList.remove('done');
          title.style.textDecoration = 'none';
          title.style.color = '';
          buttonElement.textContent = 'Selesai';
        } else {
          taskCard.classList.add('done');
          title.style.textDecoration = 'line-through';
          title.style.color = 'gray';
          buttonElement.textContent = 'Belum Selesai';
        }
      }
    })
    .catch(err => console.error('Error:', err));
  }
  

function addTask() {
    const title = document.getElementById('taskInput').value.trim();
    const date = document.getElementById('taskDate').value;
    const desc = document.getElementById('taskDesc').value.trim();
  
    if (title === '') return;
  
    const selectedCategory = document.getElementById('taskCategory').value;
    const taskData = {
      text: title,
      date: date,
      desc: desc,
      done: false,
      category: selectedCategory || (currentCategory !== 'ALL' ? currentCategory : null)
  };

  
    if (editingIndex !== null) {
      taskList[editingIndex] = { ...taskList[editingIndex], ...taskData };
      editingIndex = null;
    } else {
      taskList.push(taskData);
    }
  
    renderTasks();
    hideInput();
}

function showTaskForm(task = null) {
  const popup = document.getElementById('popups');
  popup.style.display = 'block';

  if (task) {
    editingTaskId = task._id;
    document.getElementById('taskInput').value = task.title;
    document.getElementById('taskDate').value = task.date ? new Date(task.date).toISOString().substr(0, 10) : '';
    document.getElementById('taskDesc').value = task.description || '';
    document.getElementById('taskCategory').value = task.category || '';
    document.getElementById('taskForm').action = `/todoapp/edit/${task._id}`;
    document.getElementById('formSubmitBtn').textContent = 'Simpan';
  } else {
    editingTaskId = null;
    document.getElementById('taskForm').action = '/todoapp/add';
    document.getElementById('formSubmitBtn').textContent = 'Tambah';
  }
}

function deleteCategory(index) {
  const name = categories[index];
  if (confirm(`Hapus kategori "${name}"?`)) {
    categories.splice(index, 1);

    taskList = taskList.map(task => {
      if (task.category === name) {
        task.category = null;
      }
      return task;
    });

    renderCategories();
    renderTasks();
    saveData();
  }
}

  
function renderTasks() {
  const listContainer = document.getElementById('taskList');
  listContainer.innerHTML = '';

  const filteredTasks = currentCategory === 'ALL'
    ? taskList
    : taskList.filter(task => task.category === currentCategory);

  filteredTasks.forEach((task, index) => {
    const taskDiv = document.createElement('div');
    taskDiv.className = 'task-card' + (task.done ? ' done-task' : '');
taskDiv.innerHTML = `
  <div class="task-content">
    <div class="task-text">
      <strong>${task.text}</strong><br/>
      ${task.date ? `<small>📅 ${task.date}</small><br/>` : ''}
      ${task.desc ? `<em>${task.desc}</em>` : ''}
    </div>
    <div class="task-buttons">
      <button onclick="markDone(${index})">Selesai</button>
      <button onclick="editTask(${index})">Edit</button>
      <button onclick="deleteTask(${index})">Hapus</button>

    </div>
  </div>
`;

    listContainer.appendChild(taskDiv);
  });

  document.getElementById('currentCategoryTitle').textContent = currentCategory;
}

async function deleteTask(index) {
  const task = taskList[index];

  try {
      const response = await fetch(`/todoapp/delete/${task._id}`, {
          method: "DELETE",
      });

      if (response.ok) {
          taskList.splice(index, 1); // Hapus task dari daftar
          renderTasks();
      } else {
          console.error("Failed to delete task");
      }
  } catch (err) {
      console.error("Error:", err);
  }
}

function editTask(index) {
    const task = taskList[index];
    document.getElementById('taskInput').value = task.text;
    document.getElementById('taskDate').value = task.date || '';
    document.getElementById('taskDesc').value = task.desc || '';
    document.getElementById('popup').style.display = 'block';
    editingIndex = index; // simpan index yang sedang diedit
  }
  

  async function markDone(index) {
    const task = taskList[index];

    try {
        const response = await fetch(`/todoapp/complete/${task._id}`, {
            method: "POST",
        });

        if (response.ok) {
            const data = await response.json();
            taskList[index].done = data.task.completed; // Perbarui status selesai
            renderTasks();
        } else {
            console.error("Failed to mark task as complete");
        }
    } catch (err) {
        console.error("Error:", err);
    }
}
  

  function addCategory() {
    const name = prompt("Nama kategori:");
    if (name && !categories.includes(name)) {
      categories.push(name);
      renderCategories();
      saveData();
    }
  }
  

  function renderCategories() {
    const categoryList = document.getElementById('categoryList');
    const dropdown = document.getElementById('taskCategory');
    categoryList.innerHTML = '';
    dropdown.innerHTML = '<option value="">-- Pilih Kategori --</option>';
  
    categories.forEach((cat, index) => {
      const catDiv = document.createElement('div');
      catDiv.className = 'category-item';
      catDiv.innerHTML = `
        <button onclick="setCategory('${cat}')">${cat}</button>
        <button class="delete-cat" onclick="deleteCategory(${index})">×</button>
      `;
      categoryList.appendChild(catDiv);
  
      // tambahkan ke dropdown popup tambah task
      const opt = document.createElement('option');
      opt.value = cat;
      opt.textContent = cat;
      dropdown.appendChild(opt);
    });
  }
  

function setCategory(cat) {
  currentCategory = cat;
  renderCategories();
  renderTasks();
}

function saveData() {
  localStorage.setItem('tasks', JSON.stringify(taskList));
  localStorage.setItem('categories', JSON.stringify(categories));
}

function loadData() {
  const storedTasks = localStorage.getItem('tasks');
  const storedCategories = localStorage.getItem('categories');

  if (storedTasks) taskList = JSON.parse(storedTasks);
  if (storedCategories) categories = JSON.parse(storedCategories);
}

window.onload = function () {
  loadData();
  renderCategories();
  renderTasks();
};

function toggleTaskMenu(index) {
  const menu = document.getElementById(`taskMenu${index}`);
  const allMenus = document.querySelectorAll('.task-menu');

  allMenus.forEach(m => {
    if (m !== menu) m.style.display = 'none';
  });

  // Toggle menu yang diklik
  menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

renderCategories();
renderTasks();
