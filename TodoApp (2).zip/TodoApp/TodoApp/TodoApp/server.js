const express = require("express");
const bodyParser = require("body-parser");
const session = require("express-session");
const bcrypt = require("bcrypt");
const app = express();
const PORT = 3000
const flash = require('connect-flash');

app.use(session({
  secret: "your_secret_key", // Ganti dengan secret key Anda
  resave: false,
  saveUninitialized: true,
}));

app.use(flash());

app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  next();
});
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false
}));

app.set("view engine", "ejs") // buat set tamplate ejs
app.use(express.static("public")) // buat set static file nya public
app.use(express.json());
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});


const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/todoapp')
  .then(() => console.log('Connected'))
  .catch(err => console.log('Gagal terhubung', err));

app.listen(3000, ()=>{
    console.log(`http://localhost:${PORT}`)
})

//router 
const index = require("./routes")
app.use("/", index)

const auth = require("./routes/auth")
app.use("/auth", auth)

const todoapp = require("./routes/todoapp")
app.use("/", todoapp)

const user = require("./routes/user")
app.use("/", user)

