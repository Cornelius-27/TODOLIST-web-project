
const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const User = require("../app/models/User");

// Route GET untuk halaman login
router.get("/login", (req, res) => {
    res.render("page/login", { title: "Login" });
});

// Route POST untuk login
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).render("page/login", { title: "Login", error: "Email tidak ditemukan" });
        }

        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return res.status(400).render("page/login", { title: "Login", error: "Password salah" });
        }

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || "secret", {
            expiresIn: "1h"
        });
        // Simpan user ID ke dalam session
        req.session.userId = user._id;
        req.session.user = {
            username: user.username,
            email: user.email,
        };
        // Redirect ke halaman todoapp (biar routing tetap konsisten di satu tempat)
        res.redirect("/todoapp");
    } catch (err) {
        console.error("Error during login:", err);
        res.status(500).render("page/login", { title: "Login", error: "Terjadi kesalahan saat login" });
    }
});

// Route GET untuk halaman signup
router.get("/signup", (req, res) => {
    res.render("page/signup", { title: "Signup" });
});

// Route POST untuk signup
router.post("/signup", async (req, res) => {
    const { username, email, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
        return res.render("page/signup", { title: "Signup", error: "Password tidak cocok" });
    }

    try {
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.render("page/signup", { title: "Signup", error: "Username atau email sudah terdaftar" });
        }

        const newUser = new User({ username, email, password });
        await newUser.save();

        res.redirect("/auth/login"); // Redirect ke halaman login setelah berhasil signup
    } catch (err) {
        console.error("Error during signup:", err);
        res.render("page/signup", { title: "Signup", error: "Terjadi kesalahan saat mendaftar" });
    }
});

router.get("/profile", async (req, res) => {
    try {
        const userId = req.session.userId; // Ambil user ID dari sesi
        if (!userId) {
            return res.redirect("/auth/login"); // Redirect ke login jika belum login
        }

        const user = await User.findById(userId); // Cari user berdasarkan ID
        if (!user) {
            return res.redirect("/auth/login"); // Redirect jika user tidak ditemukan
        }

        res.render("page/profile", { title: "Profile", user }); // Kirim data user ke template
    } catch (err) {
        console.error("Error loading profile:", err);
        res.status(500).send("Internal Server Error");
    }
});

router.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error("Gagal logout:", err);
            return res.status(500).send("Gagal logout");
        }

        res.redirect("/auth/login");
    });
});

module.exports = router;