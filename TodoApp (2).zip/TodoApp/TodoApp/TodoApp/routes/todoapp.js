const express = require("express");
const router = express.Router();
const Task = require("../app/models/Task");
const User = require("../app/models/User"); // Import model User

// Route GET untuk halaman /todoapp

router.get("/todoapp", async (req, res) => {
    try {
        const userId = req.session.userId;
        if (!userId) {
            return res.redirect("/auth/login");
        }

        const selectedCategory = req.query.category;
        let query = { user: userId };

        if (selectedCategory) {
            query.category = selectedCategory;
        }

        const tasks = await Task.find(query).sort({ createdAt: -1 });
        let categories = await Task.distinct("category", { user: userId });

        // Tambahkan kategori default jika belum ada
        const defaultCategories = ["tugas", "kegiatan", "penting"];
        categories = [...new Set([...categories, ...defaultCategories])];

        res.render("page/todoapp", { 
            title: "Todo App", 
            tasks, 
            categories, 
            category: selectedCategory 
        });
    } catch (err) {
        console.error("Error loading todoapp:", err);
        res.status(500).send("Internal Server Error");
    }
});


  

router.post("/todoapp", async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) return res.redirect("/auth/login");
  
      const newTask = new Task({
        title: req.body.title,
        user: userId // ⬅️ kaitkan task dengan user
      });
  
      await newTask.save();
      res.redirect("/todoapp");
    } catch (err) {
      console.error("Error creating task:", err);
      res.status(500).send("Internal Server Error");
    }
  });

  router.post("/todoapp/add", async (req, res) => {
    try {
        console.log("Form data received:", req.body); // Debugging
        const userId = req.session.userId;
        if (!userId) {
            return res.redirect("/auth/login");
        }

        const { title, date, description, category } = req.body;

        const newTask = new Task({
            title,
            date,
            description,
            category,
            user: userId,
        });

        await newTask.save();
        res.redirect("/todoapp");
    } catch (err) {
        console.error("Error adding task:", err);
        res.status(500).send("Internal Server Error");
    }
});

router.post('/todoapp/complete/:id', async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) return res.status(404).json({ success: false });
  
      task.completed = !task.completed;
      await task.save();
  
      res.json({ success: true, completed: task.completed });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
  
  

router.post("/todoapp/complete/:id", async (req, res) => {
    try {
        const taskId = req.params.id;
        const userId = req.session.userId;

        const task = await Task.findOne({ _id: taskId, user: userId });
        if (!task) {
            return res.status(404).send("Task not found");
        }

        task.completed = !task.completed;
        await task.save();

        res.redirect("/todoapp");
    } catch (err) {
        console.error("Error completing task:", err);
        res.status(500).send("Internal Server Error");
    }
});


// Route POST untuk menghapus task
router.post("/todoapp/delete/:id", async (req, res) => {
    try {
        const taskId = req.params.id;
        const userId = req.session.userId;

        const task = await Task.findOneAndDelete({ _id: taskId, user: userId });
        if (!task) {
            return res.status(404).send("Task not found");
        }

        res.redirect("/todoapp");
    } catch (err) {
        console.error("Error deleting task:", err);
        res.status(500).send("Internal Server Error");
    }
});

// Route POST untuk mengedit task
router.post("/todoapp/edit/:id", async (req, res) => {
    try {
        const taskId = req.params.id;
        const userId = req.session.userId;
        const { title, date, description, category } = req.body;

        // Cari tugas berdasarkan ID dan user
        const task = await Task.findOne({ _id: taskId, user: userId });
        if (!task) {
            return res.status(404).send("Task not found");
        }

        // Perbarui tugas dengan data baru
        task.title = title;
        task.date = date;
        task.description = description;
        task.category = category;

        // Simpan perubahan
        await task.save();
        res.redirect("/todoapp"); // Redirect ke halaman todo app setelah sukses update
    } catch (err) {
        console.error("Error editing task:", err);
        res.status(500).send("Internal Server Error");
    }
});




module.exports = router;