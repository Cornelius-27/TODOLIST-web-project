const express = require("express");
const router = express.Router();
const User = require("../app/models/User");
const bcrypt = require("bcryptjs");

// Route GET untuk halaman profile
router.get("/profile", async (req, res) => {
    try {
        const userId = req.session.userId; // Ambil user ID dari sesi
        if (!userId) {
            return res.redirect("/auth/login"); // Redirect ke login jika belum login
        }

        const user = await User.findById(userId); // Cari user berdasarkan ID
        if (!user) {
            return res.redirect("/auth/login"); // Redirect jika user tidak ditemukan
        }

        res.render("page/profile", { title: "Profile", user });
    } catch (err) {
        console.error("Error loading profile:", err);
        res.status(500).send("Internal Server Error");
    }
});

// Route POST untuk update profile
router.post("/profile", async (req, res) => {
    const { username, email, currentPassword, newPassword } = req.body;

    try {
        const userId = req.session.userId;
        if (!userId) return res.redirect("/auth/login");

        const user = await User.findById(userId);
        if (!user) return res.redirect("/auth/login");

        // Password update
        if (currentPassword && newPassword) {
            const isMatch = await user.comparePassword(currentPassword);
            if (!isMatch) {
                req.flash("error_msg", "Password lama salah");
                return res.redirect("/profile");
            }
            user.password = newPassword;
        }

        user.username = username || user.username;
        user.email = email || user.email;

        await user.save();

        req.flash("success_msg", "Profile berhasil diperbarui");
        res.redirect("/todoapp"); // redirect ke homepage atau halaman todo
    } catch (err) {
        console.error("Error updating profile:", err);
        req.flash("error_msg", "Terjadi kesalahan saat memperbarui profile");
        res.redirect("/profile");
    }
});
module.exports = router;