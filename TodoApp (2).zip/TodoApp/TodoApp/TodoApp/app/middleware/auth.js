const jwt = require("jsonwebtoken");
const session = require("express-session");

app.use(session({
    secret: "your_secret_key", // Ganti dengan secret key Anda
    resave: false,
    saveUninitialized: false,
}));

module.exports = function (req, res, next) {
  const token = req.header("Authorization")?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Access Denied" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "secret");
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).json({ message: "Invalid Token" });
  }
};

router.post("/update-profile", async (req, res) => {
  const { username, email, currentPassword, newPassword } = req.body;

  try {
      const userId = req.session.userId; // Ambil user ID dari sesi
      if (!userId) {
          return res.status(401).send("Unauthorized");
      }

      const user = await User.findById(userId); // Cari user berdasarkan ID
      if (!user) {
          return res.status(404).send("User not found");
      }

      // Validasi password lama jika ingin mengganti password
      if (currentPassword && newPassword) {
          const isMatch = await user.comparePassword(currentPassword);
          if (!isMatch) {
              return res.status(400).send("Password lama salah");
          }
          user.password = newPassword; // Set password baru
      }

      // Update username dan email
      user.username = username || user.username;
      user.email = email || user.email;

      await user.save(); // Simpan perubahan

      res.redirect("/todoapp"); // Redirect kembali ke halaman todoapp
  } catch (err) {
      console.error("Error updating profile:", err);
      res.status(500).send("Internal Server Error");
  }
});
