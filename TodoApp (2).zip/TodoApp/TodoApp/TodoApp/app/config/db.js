// config/db.js
const mongoose = require('mongoose');

const connectToDatabase = async () => {
  if (mongoose.connection.readyState === 0) { // 0 = disconnected
    try {
      await mongoose.connect('mongodb://localhost:27017/todoapp', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });
      console.log('connected');
    } catch (err) {
      console.error('connection error:', err);
    }
  } else {
    console.log('Already connected to MongoDB');
  }
};

module.exports = connectToDatabase;
